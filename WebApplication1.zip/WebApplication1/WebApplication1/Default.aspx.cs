﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication1
{
    public partial class _Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void signupUser(object sender, EventArgs e)
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "callusersignup", "adduserdata()", true);
        }


        protected void loginUser(object sender, EventArgs e)
        {

            Response.Write("<script>alert('hi');</script>");
            //ScriptManager.RegisterStartupScript(this, GetType(), "calluserlogin", "checklogindata('apj619','123456')", true);
            //Response.Write("<script>alert(calluserlogin);</script>");
        }
    }
}
